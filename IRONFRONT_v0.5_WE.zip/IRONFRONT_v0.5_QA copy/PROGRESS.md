# PROJECT IRONFRONT — Requirement / Development Status

Updated: 2026-10-08  
Build: **v0.5 AI + Major Events QA**

## Core / Conquest

- [x] Two autonomous factions + player on Blue.
- [x] 8v8 / 16v16 / 32v32 / experimental 64v64.
- [x] Five real capture points and ticket bleed.
- [x] Elimination ticket loss, respawn, victory/defeat and restart.
- [x] Default 32v32 / 500-ticket match reaches a valid result with zero player input.

## Infantry AI

- [x] All ten requested AI states are implemented and observed in deterministic simulation.
- [x] LOS/FOV-style perception, approximate gunfire reaction and target memory.
- [x] Visual and auditory perception are separated: nearby enemies behind cover create approximate SEARCH memories rather than exact through-wall visual locks.
- [x] ~4-person squads with leader, formation offset and shared awareness.
- [x] Strategic objective scoring uses ownership, contesting, force distribution, distance, assignment crowding and ticket disadvantage.
- [x] v0.5 tactical intents: ATTACK / DEFEND / FLANK / REINFORCE.
- [x] Multi-approach objective routing: different squads no longer always converge on the exact same approach.
- [x] Defender/reinforcement cover positioning around objectives.
- [x] Fire-and-move lateral combat repositioning.
- [x] Local friendly/enemy force-ratio evaluation affects retreat/cover behavior.
- [x] Difficulty now affects AI perception, memory and decision cadence as well as accuracy.
- [x] Near / mid / distant AI scheduling.
- [x] Local eight-direction navigation recovery before recording a failure.
- [x] Latest default deterministic 32v32 run: **7 navigation failures** over ~464 simulated seconds.
- [ ] Real 32v32 browser CPU profiling.

## Major battlefield events — v0.5

- [x] ARTILLERY: warning, AI avoidance response, 4 real impacts, infantry suppression/damage, vehicle damage, event VFX/audio/HUD.
- [x] COUNTER_OFFENSIVE: majority squad commitment, flank intent, morale boost, accelerated reinforcements/respawns.
- [x] ARMORED_PUSH: armor + infantry objective coordination, accelerated disabled armor return, immediate AI commitment.
- [x] Seed-randomized starting point while retaining all three event types in a recurring cycle.
- [x] HUD operation banner + tactical-map target indicator.
- [x] Full tactical map draws Blue squad approach paths; flank routes are visually distinct.
- [x] Deterministic default-match QA observed all three event types and verified counter-offensive/armored-push state changes.

## Vehicles

- [x] One V-12 Lancer per faction.
- [x] Player enter / exit, drive, collision, turret and cannon.
- [x] Vehicle health, disable, ticket impact and respawn.
- [x] Autonomous objective navigation / combat.
- [x] Major-event coordination for ARMORED_PUSH.
- [ ] Multiple seats / suspension / aircraft.

## Rendering / UI

- [x] Three.js world / terrain / structures / vegetation / fog / lighting / smoke.
- [x] Low / Medium / High graphics presets change actual rendering settings.
- [x] First-person movement and weapon animation pass.
- [x] Articulated infantry + procedural armored vehicle visuals.
- [x] Artillery blast VFX + camera feedback + synthesized positional audio.
- [x] Bilingual battle / controls / graphics / audio menus.
- [x] HUD, minimap, tactical map, scoreboard, respawn and F3 diagnostics.
- [ ] Real browser visual acceptance and sustained FPS measurement in this environment.

## Verification gate

- [x] Renderer-independent strict TypeScript compile with `tsconfig.logic.json`.
- [x] Deterministic vehicle lifecycle regression.
- [x] 8v8 / 16v16 / 32v32 / 64v64 autonomous quick-match regression.
- [x] Default 32v32 / 500 ticket idle-player regression.
- [x] Whole-source TypeScript syntax/transpile pass: 16 TS files.
- [x] Standalone strict typecheck of UI + audio modules using DOM libs.
- [ ] Fresh npm dependency install — environment DNS returns `EAI_AGAIN`.
- [ ] Real Three.js declarations / Vite build / Vitest package run / Playwright WebGL run.
