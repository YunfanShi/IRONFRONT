# PROJECT IRONFRONT v0.5 — QA REPORT

Date: 2026-10-08

## 1. Renderer-independent strict TypeScript compile

Executed:

```bash
rm -rf .logic-build
tsc -p tsconfig.logic.json
```

Result: **PASS**.

This compiles the real battle simulation, infantry AI, strategic-event logic, navigation, Conquest rules, weapon data and vehicle logic without Three.js.

## 2. Auditory / perception regression

A dedicated blocked-line-of-sight scenario places opposing bots on opposite sides of a solid crate at close range.

Result: **PASS**. The target is not visually visible, but the nearby bot forms an approximate auditory memory and enters `SEARCH` rather than receiving wall-penetrating exact visual knowledge.

## 3. Direct vehicle lifecycle regression

`node scripts/verify-core.cjs` deterministic direct test: **PASS**.

- Player entered Blue armor.
- Vehicle moved **2.10 world units** in the controlled movement step.
- Player-fired vehicle cannon disabled Red armor.
- Player exited successfully.
- Disabled Red armor respawned successfully.

## 4. Autonomous quick-match regression

Quick regressions use 36 starting tickets. Player input is zero.

| Battle | Winner | Sim time | Captures | Deaths | Respawns | Infantry shots | Vehicle shots | Vehicle disabled | Major starts | Artillery impacts | Nav failures |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 8v8 | Red | 103.750 s | 5 | 13 | 11 | 286 | 40 | 1 | 1 | 0 | 2 |
| 16v16 | Blue | 134.500 s | 5 | 54 | 49 | 738 | 103 | 0 | 1 | 0 | 1 |
| 32v32 | Blue | 85.750 s | 5 | 33 | 24 | 1,055 | 30 | 1 | 1 | 4 | 6 |
| 64v64 experimental | Blue | 74.375 s | 5 | 40 | 28 | 1,346 | 34 | 0 | 0 | 0 | 0 |

Short matches can end before the first scheduled strategic event. That is expected rather than a test failure.

All ten requested infantry states were observed across the deterministic runs:

`SPAWN`, `IDLE`, `FOLLOW_SQUAD`, `MOVE_TO_OBJECTIVE`, `SEARCH`, `ENGAGE`, `SEEK_COVER`, `DEFEND`, `RETREAT`, `RESPAWN`.

## 5. Primary/default 32v32 / 500-ticket idle-player match

Configuration: 32v32 infantry, one armored vehicle per faction, Normal AI, 500 tickets, 1 ticket per infantry elimination, seed 505.

Result: **PASS**.

- Winner: **Blue**
- Simulated duration: **464.125 seconds**
- Final tickets: **Blue 322 / Red 0**
- Objective ownership changes: **5**
- Infantry deaths: **326**
- AI infantry respawns: **322**
- Infantry shots: **6,300**
- Vehicle shots: **525**
- Major-event starts: **4**
- Artillery impacts: **4**
- Event kinds observed: **ARTILLERY / COUNTER_OFFENSIVE / ARMORED_PUSH**
- Counter-offensive effect verification: **PASS** — sufficient squads committed, a FLANK order existed, and committed approach points were spatially separated.
- Armored-push effect verification: **PASS** — infantry squads and the team armored vehicle converged on the same operation objective.
- Navigation failures: **7**

The same default-scale run in the earlier AI revision had reached navigation-failure counts in the hundreds / 1000+ range. v0.5's local escape recovery substantially reduces that failure mode while the match still completes normally.

## 6. Source validation outside the Three.js dependency gate

Executed:

```text
TypeScript transpile/syntax pass: 16 source .ts files — PASS
Strict standalone compile of src/ui/UI.ts + src/audio/AudioManager.ts with ES2022 + DOM — PASS
```

These checks catch syntax/TypeScript errors in the new UI/event/audio work, but do not replace compiling rendering code against the real `three` package declarations.

## 7. npm / browser gate

Registry probe:

```text
npm error code EAI_AGAIN
npm error syscall getaddrinfo
npm error request to https://registry.npmjs.org/three failed
reason: getaddrinfo EAI_AGAIN registry.npmjs.org
```

Therefore the following are **not claimed as executed here**:

- fresh `npm install`
- full `npm run typecheck` against real `@types/three`
- Vitest package execution
- Vite production build
- Playwright WebGL execution
- measured real-browser 16v16 / 32v32 FPS, frame pacing and memory stability

## 8. Browser acceptance commands

On a machine with npm access:

```bash
npm install
npm run typecheck
npm run test
npm run test:logic
npm run build
npx playwright install chromium
npm run test:browser
```

Manual checks should include: start/deploy, pointer lock, infantry movement/ADS/fire/reload/switching, respawn, vehicle lifecycle, tactical map squad routes, all three strategic-event presentations, F3 diagnostics, pause/restart, and a long idle 32v32 / 500-ticket match.
