# PROJECT IRONFRONT — QA BUILD v0.5

Browser-based single-player combined-arms Conquest FPS built with **TypeScript + Three.js + Vite**. The player joins Blue Team while friendly/enemy infantry and armored vehicles continue fighting, capturing objectives, taking losses, respawning and draining tickets without player input. UI: **简体中文 / English**.

v0.5 focuses on battlefield intelligence and match-scale events rather than adding decorative content only.

## Run locally

Requirements: Node.js 20.19+ (or current Node 22), npm, a modern desktop WebGL2 browser, keyboard + mouse.

```bash
npm install
npm run dev
```

Open the address printed by Vite, usually `http://localhost:5173`.

Verification commands:

```bash
npm run typecheck
npm run test
npm run test:logic
npm run build
npx playwright install chromium
npm run test:browser
```

## v0.5 AI / strategy upgrade

- Squad orders now have real tactical intents: **ATTACK / DEFEND / FLANK / REINFORCE**.
- Squads assigned to the same objective receive different approach points instead of collapsing onto the capture-point center.
- Defending/reinforcing squads prefer nearby cover positions around the objective.
- Combat AI now performs short lateral fire-and-move maneuvers instead of simply stopping for every engagement.
- Bots evaluate nearby friendly/enemy force strength; badly outnumbered or suppressed units are more willing to retreat or seek cover.
- Gunfire produces local battlefield awareness: nearby opponents can react to approximate firing locations even before direct visual contact.
- Close-range hearing is separate from vision: an enemy behind solid cover creates an imprecise SEARCH location rather than an exact through-wall lock.
- AI difficulty now changes perception distance, squad-information memory and decision cadence in addition to accuracy.
- Navigation recovery now attempts eight local escape directions before declaring a path failure. This reduced the latest seeded default 32v32 navigation-failure count to **7** instead of the previous triple-digit/1000+ recovery behavior.

## Dynamic major events

Three real game-state events cycle through a long match. Their starting point is seed-randomized so every match does not begin with the same event.

### Artillery Barrage / 炮火压制
- A strategic objective is selected.
- A warning phase is shown before impact.
- Enemy AI inside the warning area tries to move away / seek safety.
- Four real impact events land around the objective.
- Impacts apply suppression/damage to enemy infantry and can damage armor.
- Effects produce world particles, expanding blast flashes, camera feedback and positional synthesized audio.

### Counter-Offensive / 反攻浪潮
- The favored team concentrates roughly 60–70% of its squads on one strategic objective.
- Some squads receive explicit FLANK approaches rather than stacking on the same route.
- Morale receives a temporary floor/boost.
- Dead AI reinforcements are accelerated when the event begins, and deaths during the event receive a shorter respawn delay.

### Armored Push / 装甲突击
- Armor and multiple infantry squads are assigned to the same objective.
- A disabled team vehicle gets an accelerated return window.
- Idle AI armor is immediately committed to the push.
- Vehicle movement receives a modest operational tempo increase during the event.

The HUD displays the active operation, objective and remaining duration. The tactical map highlights the active event and, on the full map, shows Blue squad approach lines with flank routes distinguished visually.

## Core gameplay

- Five Conquest objectives: A Industrial Complex, B Central Village, C Railway Station, D Military Base, E Communications Facility.
- 8v8 / 16v16 / **32v32 target** / experimental 64v64. Player replaces one Blue infantry slot.
- 500 default tickets; objective imbalance ticket bleed; configurable elimination penalty; match win/loss and restart.
- Full requested infantry states: `SPAWN`, `IDLE`, `FOLLOW_SQUAD`, `MOVE_TO_OBJECTIVE`, `SEARCH`, `ENGAGE`, `SEEK_COVER`, `DEFEND`, `RETREAT`, `RESPAWN`.
- Shared enemy awareness, LOS/FOV-style perception, local hearing, cover seeking, morale/suppression and A* navigation.
- Two fictional player weapons with independent magazines/reserves, fire modes, damage/falloff, ADS, recoil and reload.
- One V-12 Lancer armored vehicle per faction with player enter/exit, steering, collision, cannon, health, disable/respawn and autonomous AI participation.

## Controls

| Input | Action |
|---|---|
| WASD | Move; while driving: throttle / steer |
| Mouse | Look / aim vehicle turret |
| Left mouse | Fire infantry weapon / vehicle cannon |
| Right mouse | Infantry ADS |
| Shift | Sprint |
| Ctrl / C | Hold / toggle crouch |
| Space | Jump |
| R | Reload |
| 1 / 2 | IF-27 Carbine / M89 Marksman |
| E | Enter / exit friendly armored vehicle |
| M | Tactical map |
| Tab | Scoreboard |
| F3 | Developer diagnostics |
| Esc | Pause / release pointer |

## Rendering / presentation

- MeshStandardMaterial, ACES tone mapping, fog, procedural terrain/roads/railway/buildings/vegetation/cloud/smoke.
- Low / Medium / High presets change actual render resolution, shadows, antialiasing, foliage and atmospheric content.
- Articulated instanced infantry with smoothed movement, limb gait, combat posture, cover crouch and non-gory fall animation.
- First-person weapon models with hands, ADS, sprint, reload, swap, sway, recoil, muzzle flash and ejected cases.
- Real battle events drive tracers, impacts, artillery blast effects, vehicle cannon traces, damage feedback and hit marker.
- Web Audio provides locally generated positional combat sounds without remote assets.

## QA included

- `src/tests/Conquest.test.ts` — Vitest logic tests.
- `scripts/verify-core.cjs` — deterministic renderer-independent regression test.
- `tests/browser.spec.ts` — Playwright browser smoke test for a machine with dependencies installed.
- `QA_RESULTS.json` — exact latest deterministic output from this build.
- `QA_REPORT.md` — what was actually executed vs what remains browser-pending.

## Honest limitations

- Procedural browser visuals are not Battlefield-class authored AAA assets or motion capture.
- Only ground armor is implemented; aircraft, helicopters, multiple vehicle seats and destructible structures remain future work.
- Real browser performance remains unmeasured in this execution environment.
- This environment currently cannot resolve `registry.npmjs.org` (`EAI_AGAIN`), so a real `npm install`, real Three.js typecheck, Vite build, Vitest package run and Playwright WebGL run cannot honestly be marked as completed here.
