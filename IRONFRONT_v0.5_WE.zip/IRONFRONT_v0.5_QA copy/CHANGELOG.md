# Changelog

## v0.5 — AI & Major Events

- Added squad tactical intents: Attack, Defend, Flank, Reinforce.
- Added objective approach offsets and defensive cover approaches.
- Added local force-ratio decisions, fire-and-move combat behavior and gunfire reaction.
- Expanded AI difficulty beyond accuracy into perception / memory / decision cadence.
- Reworked stuck recovery with local eight-direction escape sampling.
- Added recurring Artillery Barrage, Counter-Offensive and Armored Push strategic events.
- Added artillery warning/impact gameplay, VFX, audio and HUD telemetry.
- Added counter-offensive reinforcement effects and armored-push combined-arms coordination.
- Added tactical-map squad approach routes and major-event target highlighting.
- Expanded deterministic QA to verify recurring event types and event effects.
