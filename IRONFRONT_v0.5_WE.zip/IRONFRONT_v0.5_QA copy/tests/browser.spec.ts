import {test,expect} from '@playwright/test';

test('menu exposes the required setup surfaces',async({page})=>{
 const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));await page.goto('/');
 await expect(page.locator('#play')).toBeVisible();await expect(page.getByRole('button',{name:/战局|BATTLE/})).toBeVisible();
 await page.getByRole('button',{name:/画面|GRAPHICS/}).click();await expect(page.locator('#setup-quality')).toBeVisible();await expect(page.locator('#setup-fov')).toBeVisible();
 await page.getByRole('button',{name:/音频|AUDIO/}).click();await expect(page.locator('#setup-volume')).toBeVisible();
 await page.getByRole('button',{name:/操作|CONTROLS/}).click();await expect(page.locator('kbd').filter({hasText:'1 / 2'})).toBeVisible();expect(errors).toEqual([]);
});

test('starts a battle, shows HUD, pause and diagnostics',async({page})=>{
 const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));await page.goto('/');
 await page.getByRole('button',{name:/战局|BATTLE/}).click();await page.locator('#setup-size').selectOption('8');await page.locator('#play').click();
 await expect(page.locator('#battle-canvas')).toBeVisible();await expect(page.locator('#hud')).not.toHaveClass(/hidden/);await expect(page.locator('#player-stats')).toContainText(/HP/);
 await page.keyboard.press('F3');await expect(page.locator('#debug')).not.toHaveClass(/hidden/);await page.keyboard.press('Escape');await expect(page.locator('#resume')).toBeVisible();expect(errors).toEqual([]);
});
