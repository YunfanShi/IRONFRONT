export type WeaponId='carbine'|'marksman';

export interface WeaponDefinition {
 id:WeaponId;
 name:string;
 zh:string;
 damage:number;
 fireInterval:number;
 magazine:number;
 reserve:number;
 reload:number;
 effectiveRange:number;
 maxRange:number;
 hipSpread:number;
 adsSpread:number;
 recoil:number;
 automatic:boolean;
}

export const WEAPONS:Record<WeaponId,WeaponDefinition>={
 carbine:{id:'carbine',name:'IF-27 Carbine',zh:'IF-27 卡宾枪',damage:31,fireInterval:.105,magazine:30,reserve:150,reload:1.9,effectiveRange:92,maxRange:165,hipSpread:.010,adsSpread:.0022,recoil:.14,automatic:true},
 marksman:{id:'marksman',name:'M89 Marksman',zh:'M89 精确射手步枪',damage:58,fireInterval:.32,magazine:12,reserve:60,reload:2.35,effectiveRange:145,maxRange:220,hipSpread:.016,adsSpread:.0011,recoil:.24,automatic:false}
};

export const WEAPON_ORDER:WeaponId[]=['carbine','marksman'];
