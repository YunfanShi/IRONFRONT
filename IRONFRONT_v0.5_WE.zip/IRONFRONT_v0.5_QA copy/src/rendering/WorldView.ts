import * as THREE from 'three';
import {Random,heightAt,dist} from '../core/math';
import {MAP_SIZE,BLOCKS,OBJECTIVES,BASES,OPEN_BUILDINGS,collides,type Team} from '../world/Layout';
import type {Battle,BattleEvent} from '../core/Battle';
import {EnvironmentArt} from './EnvironmentArt';
import {SoldierVisuals} from './SoldierVisuals';
import {WeaponView} from './WeaponView';
import {WEAPONS,type WeaponId} from '../combat/Weapons';
import {VehicleVisuals} from './VehicleVisuals';

const material=(hex:number,roughness=.9,metalness=.0)=>new THREE.MeshStandardMaterial({color:hex,roughness,metalness});
const amber=material(0xa38c62),concrete=material(0x777b75),tin=material(0x596f77,.62,.37),roof=material(0x303e41,.72,.21),house=material(0xb1a188),olive=material(0x57654f);
const metal=material(0x47565b,.52,.55),dark=material(0x272c2c),blue=0x66c4fd,red=0xff806c;
const cube=(w:number,h:number,d:number,mat:THREE.Material)=>new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mat);
function makeFlag(label:string):THREE.Sprite {
 const can=document.createElement('canvas');can.width=128;can.height=128;const c=can.getContext('2d')!;
 c.fillStyle='rgba(10,26,33,.90)';c.beginPath();c.arc(64,64,47,0,Math.PI*2);c.fill();
 c.strokeStyle='#c2dfdf';c.lineWidth=3;c.stroke();c.fillStyle='white';c.font='bold 70px Arial';c.textAlign='center';c.textBaseline='middle';c.fillText(label,64,67);
 const sprite=new THREE.Sprite(new THREE.SpriteMaterial({map:new THREE.CanvasTexture(can),transparent:true,depthTest:false}));sprite.scale.set(14,14,1);return sprite;
}
type FX={position:THREE.Vector3;velocity:THREE.Vector3;color:THREE.Color;life:number;max:number};
export interface LookState {yaw:number;pitch:number;height:number;ads:boolean;moving:boolean;sprint:boolean;reload:boolean;speed:number;side:number;paused?:boolean}
export class WorldView {
 readonly scene=new THREE.Scene();readonly renderer:THREE.WebGLRenderer;
 readonly camera:THREE.PerspectiveCamera;readonly weapon:WeaponView;
 private soldierRender:SoldierVisuals;private vehicleRender:VehicleVisuals;private art:EnvironmentArt;
 private markers:{ring:THREE.Mesh;label:THREE.Sprite;beam:THREE.Mesh}[]=[];
 private tracer:{line:THREE.Line;life:number}[]=[];
 private blastFx:{mesh:THREE.Mesh;life:number;max:number;radius:number}[]=[];
 private particles:FX[]=[];private particleCloud:THREE.Points;
 private positionData=new Float32Array(1200*3);private colorData=new Float32Array(1200*3);
 private t=0;private high:boolean;private medium:boolean;private sun:THREE.DirectionalLight;private shadowEnabled:boolean;
 private cameraKick=0;private vignette:HTMLDivElement|null=null;private smoke:{sprite:THREE.Sprite;baseX:number;baseY:number;baseScale:number;phase:number}[]=[];
 constructor(private canvas:HTMLCanvasElement,battle:Battle,quality:'low'|'medium'|'high',private baseFov=79){
  this.high=quality==='high';this.medium=quality==='medium';this.shadowEnabled=quality!=='low';
  this.renderer=new THREE.WebGLRenderer({canvas,antialias:quality!=='low',powerPreference:'high-performance',alpha:false});
  const ratio=this.high?1.75:this.medium?1.35:1;this.renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,ratio));
  this.renderer.outputColorSpace=THREE.SRGBColorSpace;this.renderer.toneMapping=THREE.ACESFilmicToneMapping;this.renderer.toneMappingExposure=1.34;
  this.renderer.shadowMap.enabled=this.shadowEnabled;this.renderer.shadowMap.type=THREE.PCFSoftShadowMap;
  this.camera=new THREE.PerspectiveCamera(this.baseFov,1,.08,960);
  this.scene.background=new THREE.Color(0x97b6c5);this.scene.fog=new THREE.FogExp2(0xa7afb0,this.high ? .00255 : this.medium ? .00315 : .00415);
  this.scene.add(new THREE.HemisphereLight(0xcdeaff,0x595b4b,this.high?1.85:1.65));
  this.sun=new THREE.DirectionalLight(0xffe3bd,this.high?3.25:this.medium?2.85:2.35);this.sun.position.set(160,240,-125);
  if(this.shadowEnabled){this.sun.castShadow=true;const map=this.high?2048:1024;this.sun.shadow.mapSize.set(map,map);const span=this.high?110:86;this.sun.shadow.camera.left=-span;this.sun.shadow.camera.right=span;this.sun.shadow.camera.top=span;this.sun.shadow.camera.bottom=-span;this.sun.shadow.camera.near=1;this.sun.shadow.camera.far=550;this.sun.shadow.bias=-.00035;this.sun.shadow.normalBias=.035}
  this.scene.add(this.sun,this.sun.target);
  this.buildTerrain();this.buildEnvironment();this.buildFoliage(this.high?520:this.medium?310:155);this.art=new EnvironmentArt(this.scene,this.high||this.medium);this.buildAmbientSmoke();
  this.buildMarkers();this.soldierRender=new SoldierVisuals(this.scene,battle);this.vehicleRender=new VehicleVisuals(this.scene,battle);
  this.weapon=new WeaponView(this.camera,this.scene);
  const particles=new THREE.BufferGeometry();particles.setAttribute('position',new THREE.BufferAttribute(this.positionData,3));particles.setAttribute('color',new THREE.BufferAttribute(this.colorData,3));particles.setDrawRange(0,0);
  const dot=this.particleTexture();
  this.particleCloud=new THREE.Points(particles,new THREE.PointsMaterial({map:dot,size:this.high ? .82 : this.medium ? .68 : .54,transparent:true,vertexColors:true,depthWrite:false,blending:THREE.AdditiveBlending,sizeAttenuation:true}));
  this.particleCloud.frustumCulled=false;this.scene.add(this.particleCloud);
  this.vignette=document.querySelector('#damage-vignette');
  this.resize();window.addEventListener('resize',this.resize);
 }
 resize=()=>{const w=Math.max(1,this.canvas.clientWidth),h=Math.max(1,this.canvas.clientHeight);this.camera.aspect=w/h;this.camera.updateProjectionMatrix();this.renderer.setSize(w,h,false)};
 private particleTexture(){const can=document.createElement('canvas');can.width=64;can.height=64;const c=can.getContext('2d')!;
  const g=c.createRadialGradient(32,32,0,32,32,30);g.addColorStop(0,'rgba(255,255,255,1)');g.addColorStop(.2,'rgba(255,255,255,.94)');g.addColorStop(1,'rgba(255,255,255,0)');c.fillStyle=g;c.fillRect(0,0,64,64);return new THREE.CanvasTexture(can)
 }
 private addBlock(x:number,y:number,z:number,w:number,h:number,d:number,mat:THREE.Material,casts=true){
  const m=cube(w,h,d,mat);m.position.set(x,y+h/2,z);m.castShadow=this.shadowEnabled&&casts;m.receiveShadow=true;this.scene.add(m);return m;
 }
 private groundTexture(){const can=document.createElement('canvas');can.width=256;can.height=256;const c=can.getContext('2d')!;let seed=12222;
  const rng=()=>{seed=(Math.imul(seed,1664525)+1013904223)|0;return (seed>>>0)/4294967296};
  c.fillStyle='#a2ad8d';c.fillRect(0,0,256,256);
  for(let i=0;i<12000;i++){const l=50+rng()*43;const a=.025+rng()*.12;c.fillStyle=`rgba(${l},${l+12},${l-5},${a})`;
   const x=rng()*256,y=rng()*256;c.fillRect(x,y,1+rng()*3,1+rng()*5)
  }const tex=new THREE.CanvasTexture(can);tex.wrapS=tex.wrapT=THREE.RepeatWrapping;tex.repeat.set(35,35);tex.anisotropy=8;tex.colorSpace=THREE.SRGBColorSpace;return tex;
 }
 private buildTerrain(){
  const g=new THREE.PlaneGeometry(MAP_SIZE,MAP_SIZE,120,120);g.rotateX(-Math.PI/2);
  const pos=g.attributes.position as THREE.BufferAttribute,colors:number[]=[];
  const low=new THREE.Color(0x75866a),high=new THREE.Color(0xa7a28a),rand=new Random(44809);
  for(let i=0;i<pos.count;i++){
   const x=pos.getX(i),z=pos.getZ(i),y=heightAt(x,z);pos.setY(i,y);
   const c=low.clone().lerp(high,Math.min(.75,y/28));c.multiplyScalar(.86+rand.between(0,.22));colors.push(c.r,c.g,c.b);
  }
  g.setAttribute('color',new THREE.Float32BufferAttribute(colors,3));g.computeVertexNormals();
  const ground=new THREE.Mesh(g,new THREE.MeshStandardMaterial({map:this.groundTexture(),vertexColors:true,roughness:1,metalness:0,side:THREE.DoubleSide}));
  ground.receiveShadow=this.shadowEnabled;this.scene.add(ground);
  const roads=[[[ -320,-296],[-185,-210],[-58,-180],[37,-62],[140,65],[301,296]], [[-291,160],[-171,116],[-26,80],[140,113],[302,154]], [[-210,-144],[-15,-92],[17,80],[-186,185]]];
  for(const points of roads)for(let j=0;j<points.length-1;j++)this.road({x:points[j]![0]!,z:points[j]![1]!},{x:points[j+1]![0]!,z:points[j+1]![1]!},11);
  // Railroad: ballast, sleepers, rails, raised steel edges.
  for(const z of [47,132]){
   this.addBlock(8,.02,z,590,.28,10.4,material(0x77756d),false);
   for(const side of [-2.6,2.6])this.addBlock(8,.30,z+side,590,.19,.31,metal,false);
   for(let x=-286;x<295;x+=7.6)this.addBlock(x,.05,z,1.1,.28,9.4,dark,false);
  }
 }
 private road(a:{x:number;z:number},b:{x:number;z:number},width:number){
  const len=Math.hypot(a.x-b.x,a.z-b.z),n=Math.ceil(len/4);const vertices:number[]=[],indices:number[]=[];
  const nx=-(b.z-a.z)/len*width/2,nz=(b.x-a.x)/len*width/2;
  for(let i=0;i<=n;i++){const t=i/n,x=a.x+(b.x-a.x)*t,z=a.z+(b.z-a.z)*t;
   for(const v of [-1,1])vertices.push(x+nx*v,heightAt(x+nx*v,z+nz*v)+.13,z+nz*v);
   if(i<n){const k=i*2;indices.push(k,k+1,k+2,k+1,k+3,k+2)}
  }const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));g.setIndex(indices);g.computeVertexNormals();
  const m=new THREE.Mesh(g,material(0x8d8779,1));m.receiveShadow=this.shadowEnabled;this.scene.add(m);
 }
 private buildEnvironment(){
  const windows=material(0x1e363b,.24,.28),rim=material(0x9a9181);
  for(const b of BLOCKS){const y=heightAt(b.x,b.z);
   let mat=concrete;if(b.kind==='house')mat=house;else if(b.kind==='barracks')mat=olive;
   else if(b.kind==='container')mat=tin;else if(b.kind==='railcar')mat=metal;else if(b.kind==='crate')mat=amber;
   this.addBlock(b.x,y,b.z,b.w,b.h,b.d,mat);
   if(['factory','house','barracks'].includes(b.kind)){
    this.addBlock(b.x,y+b.h,b.z,b.w+1.6,.7,b.d+1.6,roof);
    // Proper entrance with realistic trim, recessed door glass and visible lintel.
    this.addBlock(b.x,y,b.z+b.d/2+.19,4.3,4.85,.28,metal,false);
    this.addBlock(b.x,y+4.7,b.z+b.d/2+.35,5.15,.27,.4,rim,false);
    this.addBlock(b.x,y+2.75,b.z+b.d/2+.39,1.35,1.1,.08,windows,false);
    for(const s of [-1,1])this.addBlock(b.x+s*2.4,y,b.z+b.d/2+.32,.21,5,.25,rim,false);
   }
   if(b.kind==='railcar')for(const side of [-1,1]){
    const wheel=new THREE.Mesh(new THREE.CylinderGeometry(1.5,1.5,.6,12),dark);wheel.rotation.x=Math.PI/2;wheel.position.set(b.x+side*5,y+1,b.z+b.d/2);this.scene.add(wheel)
   }
  }
  for(const g of OPEN_BUILDINGS){const y=heightAt(g.x,g.z);
   this.addBlock(g.x,y+g.h,g.z,g.w+1,1.0,g.d+1,roof);
   this.addBlock(g.x,y,g.z,g.w-.8,.2,g.d-.8,concrete);
  }
  const mast=new THREE.Mesh(new THREE.CylinderGeometry(.45,1.7,69,8),metal);mast.position.set(-185,heightAt(-185,244)+34.5,244);mast.castShadow=this.shadowEnabled;this.scene.add(mast);
  for(let i=10;i<70;i+=13){this.addBlock(-185,heightAt(-185,244)+i,244,18,.45,.55,dark,false);this.addBlock(-185,heightAt(-185,244)+i,244,.55,.45,18,dark,false)}
  const light=new THREE.PointLight(0xff8574,9,55);light.position.set(-185,heightAt(-185,244)+70,244);this.scene.add(light);
  for(const [x,z] of [[-29,189],[96,-201]] as [number,number][])this.addBlock(x,heightAt(x,z)+7,z,31,1.1,24,tin);
  for(const team of ['blue','red'] as Team[]){const p=BASES[team];const paint=team==='blue'?0x37718a:0x8b534b;
   this.addBlock(p.x,heightAt(p.x,p.z),p.z-21,40,.6,16,material(paint));
   const pole=new THREE.Mesh(new THREE.CylinderGeometry(.16,.16,14,8),metal);pole.position.set(p.x,heightAt(p.x,p.z)+7,p.z);this.scene.add(pole)
  }
 }
 private buildFoliage(count:number){
  const rand=new Random(22305);
  const trunkGeo=new THREE.CylinderGeometry(.38,.71,5.0,7),leafGeo=new THREE.ConeGeometry(4.2,10.8,8);
  const trunks=new THREE.InstancedMesh(trunkGeo,material(0x66533c),count),foliage=new THREE.InstancedMesh(leafGeo,material(0x3a624e),count*2);
  const d=new THREE.Object3D();let added=0;
  while(added<count){const x=rand.between(-345,345),z=rand.between(-345,345);
   if(collides(x,z,5)||OBJECTIVES.some(o=>dist({x,z},o)<31)||Math.abs(z-47)<12||Math.abs(z-132)<12)continue;
   const h=heightAt(x,z),s=rand.between(.65,1.55),yaw=rand.between(0,6.28);
   d.scale.setScalar(s);d.rotation.y=yaw;d.position.set(x,h+2.4*s,z);d.updateMatrix();trunks.setMatrixAt(added,d.matrix);
   d.position.y=h+8.4*s;d.scale.setScalar(s);d.updateMatrix();foliage.setMatrixAt(added*2,d.matrix);
   d.position.y=h+13.2*s;d.scale.setScalar(s*.71);d.updateMatrix();foliage.setMatrixAt(added*2+1,d.matrix);added++;
  }trunks.instanceMatrix.needsUpdate=true;foliage.instanceMatrix.needsUpdate=true;
  foliage.castShadow=this.shadowEnabled&&this.high;trunks.castShadow=this.shadowEnabled&&this.high;this.scene.add(trunks,foliage)
 }
 private smokeTexture(){const can=document.createElement('canvas');can.width=128;can.height=128;const c=can.getContext('2d')!;const g=c.createRadialGradient(64,64,6,64,64,60);g.addColorStop(0,'rgba(78,84,82,.56)');g.addColorStop(.45,'rgba(94,98,92,.30)');g.addColorStop(1,'rgba(95,101,99,0)');c.fillStyle=g;c.fillRect(0,0,128,128);return new THREE.CanvasTexture(can)}
 private buildAmbientSmoke(){if(!this.medium&&!this.high)return;const tex=this.smokeTexture(),spots=[[-269,-170],[-163,-191],[82,127],[-246,229],[247,207]] as [number,number][];let i=0;for(const [x,z] of spots){for(let j=0;j<(this.high?3:2);j++){const mat=new THREE.SpriteMaterial({map:tex,transparent:true,depthWrite:false,opacity:.16,fog:true,color:0xa3a6a1});const sprite=new THREE.Sprite(mat);const baseY=heightAt(x,z)+18+j*8;sprite.position.set(x+(j-1)*2.3,baseY,z);const scale=15+j*6;sprite.scale.set(scale,scale*.85,1);this.scene.add(sprite);this.smoke.push({sprite,baseX:x+(j-1)*2.3,baseY,baseScale:scale,phase:i++*.91+j*.37})}}}
 private updateAmbientSmoke(dt:number){for(const s of this.smoke){s.phase+=dt*.18;s.sprite.position.y=s.baseY+Math.sin(s.phase)*2.1;s.sprite.position.x=s.baseX+Math.sin(s.phase*.53)*2.6;const pulse=.88+Math.sin(s.phase*.7)*.12;s.sprite.scale.set(s.baseScale*pulse,s.baseScale*.85*pulse,1);const m=s.sprite.material as THREE.SpriteMaterial;m.opacity=.11+(Math.sin(s.phase)+1)*.035}}
 private buildMarkers(){
  for(const o of OBJECTIVES){const y=heightAt(o.x,o.z);
   const ringGeo=new THREE.RingGeometry(21.1,22.5,64);ringGeo.rotateX(-Math.PI/2);
   const ring=new THREE.Mesh(ringGeo,new THREE.MeshBasicMaterial({color:0xd9f0eb,transparent:true,opacity:.4,depthWrite:false,side:THREE.DoubleSide}));ring.position.set(o.x,y+.3,o.z);this.scene.add(ring);
   const label=makeFlag(o.id);label.position.set(o.x,y+25,o.z);this.scene.add(label);
   const beam=new THREE.Mesh(new THREE.CylinderGeometry(7,11,45,24,1,true),new THREE.MeshBasicMaterial({color:0x6abde8,transparent:true,opacity:.042,depthWrite:false,side:THREE.DoubleSide,blending:THREE.AdditiveBlending}));beam.position.set(o.x,y+22.5,o.z);this.scene.add(beam);
   this.markers.push({ring,label,beam});
  }
 }
 onMouse(dx:number,dy:number){this.weapon.onMouse(dx,dy)}
 playerShot(weapon:WeaponId){this.weapon.shoot(weapon);this.cameraKick=Math.min(.18,this.cameraKick+WEAPONS[weapon].recoil*.24)}
 private spawnSpark(x:number,y:number,z:number,color:number,count:number){
  for(let n=0;n<count&&this.particles.length<950;n++){
   const rnd=Math.random(),direction=new THREE.Vector3(Math.random()-.5,Math.random()*1.3,Math.random()-.5).normalize();
   this.particles.push({position:new THREE.Vector3(x,y,z),velocity:direction.multiplyScalar(2+rnd*6),color:new THREE.Color(color),life:.24+rnd*.43,max:.24+rnd*.43})
  }
 }
 showEvents(events:BattleEvent[],player:{x:number;z:number}){
  for(const e of events){
   if((e.type==='shot'||e.type==='vehicleShot')&&dist(e.from,player)<220){
    const vehicle=e.type==='vehicleShot';const start=new THREE.Vector3(e.from.x,heightAt(e.from.x,e.from.z)+(vehicle?2.75:1.4),e.from.z);
    const end=new THREE.Vector3(e.to.x,heightAt(e.to.x,e.to.z)+(vehicle ? .85 : 1.35),e.to.z);
    if(start.distanceTo(end)>160)end.lerp(start,.35);
    const line=new THREE.Line(new THREE.BufferGeometry().setFromPoints([start,end]),new THREE.LineBasicMaterial({color:e.team==='blue'?0xffdfa3:0xffab82,transparent:true,opacity:vehicle ? .92 : .78,depthWrite:false,blending:THREE.AdditiveBlending}));
    this.scene.add(line);this.tracer.push({line,life:.095});
    if(vehicle||Math.random()<.7)this.spawnSpark(end.x,end.y,end.z,e.hit?0xf7c18a:0xdcc6a2,vehicle?20:e.hit?9:4);
   }else if(e.type==='vehicleDisabled'){this.spawnSpark(e.at.x,heightAt(e.at.x,e.at.z)+1.7,e.at.z,0xffaa69,42);
   }else if(e.type==='artilleryImpact'){const y=heightAt(e.at.x,e.at.z)+1.0;this.spawnSpark(e.at.x,y,e.at.z,0xffb063,this.high?90:58);const mesh=new THREE.Mesh(new THREE.SphereGeometry(1,16,10),new THREE.MeshBasicMaterial({color:0xffa35b,transparent:true,opacity:.34,depthWrite:false,blending:THREE.AdditiveBlending}));mesh.position.set(e.at.x,y,e.at.z);this.scene.add(mesh);this.blastFx.push({mesh,life:.58,max:.58,radius:e.radius*.72});const d=dist(e.at,player);if(d<105)this.cameraKick=Math.min(.42,this.cameraKick+(1-d/105)*.26);
   }else if(e.type==='death'){
    // No gore; a brief dust/debris puff marks an actual soldier elimination.
    const victim=this.lastBattle?.soldiers[e.victim];if(victim&&dist(victim.pos,player)<120)this.spawnSpark(victim.pos.x,heightAt(victim.pos.x,victim.pos.z)+.7,victim.pos.z,0xada18b,12)
   }
  }
 }
 private lastBattle:Battle|null=null;
 private updateBlastFx(dt:number){for(let i=this.blastFx.length-1;i>=0;i--){const b=this.blastFx[i]!;b.life-=dt;if(b.life<=0){this.scene.remove(b.mesh);b.mesh.geometry.dispose();(b.mesh.material as THREE.Material).dispose();this.blastFx.splice(i,1);continue}const t=1-b.life/b.max,scale=.8+b.radius*t;b.mesh.scale.setScalar(scale);(b.mesh.material as THREE.MeshBasicMaterial).opacity=(1-t)*.34}}
 private updateParticles(dt:number){
  let count=0;
  for(let i=this.particles.length-1;i>=0;i--){const p=this.particles[i]!;p.life-=dt;if(p.life<=0){this.particles.splice(i,1);continue}
   p.velocity.y-=dt*12;p.velocity.multiplyScalar(Math.max(0,1-dt*1.7));p.position.addScaledVector(p.velocity,dt);
   this.positionData[count*3]=p.position.x;this.positionData[count*3+1]=p.position.y;this.positionData[count*3+2]=p.position.z;
   const fade=p.life/p.max;this.colorData[count*3]=p.color.r*fade;this.colorData[count*3+1]=p.color.g*fade;this.colorData[count*3+2]=p.color.b*fade;count++;
  }
  this.particleCloud.geometry.setDrawRange(0,count);
  (this.particleCloud.geometry.attributes.position as THREE.BufferAttribute).needsUpdate=true;
  (this.particleCloud.geometry.attributes.color as THREE.BufferAttribute).needsUpdate=true;
 }
 render(battle:Battle,dt:number,look:LookState){
  this.lastBattle=battle;this.t+=dt;
  const p=battle.player,vehicle=battle.playerVehicle;
  if(vehicle)this.camera.position.set(vehicle.pos.x,heightAt(vehicle.pos.x,vehicle.pos.z)+3.22,vehicle.pos.z);else this.camera.position.set(p.pos.x,heightAt(p.pos.x,p.pos.z)+look.height,p.pos.z);
  this.camera.rotation.order='YXZ';this.camera.rotation.y=look.yaw;this.camera.rotation.x=look.pitch-this.cameraKick;
  this.cameraKick=THREE.MathUtils.damp(this.cameraKick,0,17,dt);
  const aim=this.weapon.render(dt,{weapon:battle.playerWeapon,ads:look.ads&&!vehicle,sprint:look.sprint&&!vehicle,moving:look.moving,speed:look.speed,reload:look.reload,alive:p.alive&&!vehicle,velocitySide:look.side});
  const sway=look.moving?Math.sin(this.t*(look.sprint?15:11))*.011*(look.sprint?1.5:1):0;
  this.camera.position.y+=sway*(1-aim*.65);
  this.camera.rotation.z+=look.side*.013;
  const adsFov=battle.playerWeapon==='marksman'?45:52;this.camera.fov=THREE.MathUtils.damp(this.camera.fov,THREE.MathUtils.lerp(this.baseFov,adsFov,aim)+(look.sprint?3:0),13,dt);this.camera.updateProjectionMatrix();
  this.soldierRender.update(battle,dt);this.vehicleRender.update(dt);
  for(let i=0;i<this.markers.length;i++){
   const owner=battle.points[i]!.owner,color=owner==='blue'?blue:owner==='red'?red:0xdbddd2;
   (this.markers[i]!.ring.material as THREE.MeshBasicMaterial).color.setHex(color);
   this.markers[i]!.label.material.color.setHex(color);
   (this.markers[i]!.beam.material as THREE.MeshBasicMaterial).color.setHex(color);
   (this.markers[i]!.beam.material as THREE.MeshBasicMaterial).opacity=.028+(Math.sin(this.t*2+i)+1)*.012;
  }
  // Camera-centred shadow coverage: nearby soldiers/buildings remain readable.
  if(this.shadowEnabled){this.sun.position.set(p.pos.x+160,240,p.pos.z-125);this.sun.target.position.set(p.pos.x,0,p.pos.z);this.sun.target.updateMatrixWorld()}
  this.updateParticles(dt);this.updateBlastFx(dt);this.updateAmbientSmoke(dt);
  for(let i=this.tracer.length-1;i>=0;i--){const t=this.tracer[i]!;t.life-=dt;if(t.life<=0){this.scene.remove(t.line);t.line.geometry.dispose();(t.line.material as THREE.Material).dispose();this.tracer.splice(i,1)}}
  if(this.vignette){this.vignette.style.opacity=String(Math.max(0,(1-p.hp/100)*.38));}
  this.renderer.render(this.scene,this.camera);
 }
 dispose(){
  window.removeEventListener('resize',this.resize);this.weapon.dispose();this.soldierRender.dispose();this.vehicleRender.dispose();this.art.dispose();
  // THREE.Scene.clear does not free GPU resources: release all generated assets on restart.
  const geometries=new Set<THREE.BufferGeometry>(),materials=new Set<THREE.Material>(),textures=new Set<THREE.Texture>();
  this.scene.traverse((o:THREE.Object3D)=>{
   const mesh=o as THREE.Mesh;
   if(mesh.geometry instanceof THREE.BufferGeometry)geometries.add(mesh.geometry);
   if(mesh.material){const list=Array.isArray(mesh.material)?mesh.material:[mesh.material];
    for(const m of list)if(m instanceof THREE.Material){materials.add(m);const mm=m as THREE.MeshStandardMaterial & {map?:THREE.Texture};if(mm.map)textures.add(mm.map)}
   }
  });
  for(const g of geometries)g.dispose();for(const t of textures)t.dispose();for(const m of materials)m.dispose();
  this.renderer.dispose();this.scene.clear();
 }
}
