import type {Point} from '../core/math';
import type {Team} from '../world/Layout';

export interface ArmoredVehicle {
 id:number;
 team:Team;
 pos:Point;
 yaw:number;
 turretYaw:number;
 hp:number;
 maxHp:number;
 alive:boolean;
 disabledAt:number;
 respawnAt:number;
 speed:number;
 driver:'ai'|'player'|null;
 goal:string;
 route:Point[];
 nextPath:number;
 nextDecision:number;
 nextShot:number;
 stuckFor:number;
 lastProgress:Point;
}

export const VEHICLE={
 maxHp:420,
 radius:3.15,
 maxForward:13.2,
 maxReverse:5.8,
 acceleration:8.4,
 braking:10.5,
 turnRate:1.08,
 weaponDamage:74,
 weaponInterval:1.15,
 weaponRange:175,
 respawnDelay:24,
} as const;

export const VEHICLE_SPAWNS:{blue:Point;red:Point}={
 blue:{x:-304,z:-302},
 red:{x:304,z:302},
};

export function createArmoredVehicles():ArmoredVehicle[]{
 return (['blue','red'] as Team[]).map((team,id)=>{
  const p=VEHICLE_SPAWNS[team];
  return {id,team,pos:{...p},yaw:team==='blue'?0:Math.PI,turretYaw:team==='blue'?0:Math.PI,hp:VEHICLE.maxHp,maxHp:VEHICLE.maxHp,alive:true,disabledAt:-999,respawnAt:0,speed:0,driver:team==='blue'?null:'ai',goal:'C',route:[],nextPath:0,nextDecision:team==='blue'?18:.5,nextShot:0,stuckFor:0,lastProgress:{...p}};
 });
}
